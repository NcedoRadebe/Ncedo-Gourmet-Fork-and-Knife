## Styling

This project uses CSS for styling and Bootstrap for responsive layout and components.
