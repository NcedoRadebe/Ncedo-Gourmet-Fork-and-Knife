# Ncedo's Gourmet Fork and Knife

A responsive restaurant website developed using HTML, CSS, JavaScript and Bootstrap.

## Project Overview

This project is a restaurant website designed to provide customers with information about the restaurant, menu, services, gallery, testimonials, bookings and contact details.

## Features

- Home page
- About section
- Restaurant menu
- Gallery
- Testimonials
- Booking form
- Contact information
- Responsive design

## Technologies Used

- HTML5
- CSS3
- JavaScript
- Bootstrap

## Live Website

https://ncedobusinessprofile.netlify.app/

## Developer

Ncedo Radebe