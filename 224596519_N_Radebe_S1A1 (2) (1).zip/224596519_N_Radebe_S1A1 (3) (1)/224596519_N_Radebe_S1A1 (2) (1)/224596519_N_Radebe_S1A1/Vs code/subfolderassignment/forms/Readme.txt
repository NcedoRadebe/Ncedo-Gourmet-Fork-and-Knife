## Contact Form

The website includes a contact/booking form interface for customers to provide their details and enquiries.

The project uses the front-end form structure provided by the website template and was customised as part of the restaurant website project.
